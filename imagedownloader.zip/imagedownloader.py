import requests  #do pip install request-html 
from bs4 import BeautifulSoup#do pip install BS4
import os
from selenium import webdriver#do pip install selenium
from selenium.webdriver.support.ui import WebDriverWait
def openurl(url):#Function is responsible for opening the website using url provided by users
    driver=webdriver.Chrome('F:\\chromedriver_win32\\chromedriver.exe')#this is chromedriver which is to be downloaded and provided for open chrome'''
    wait = WebDriverWait(driver,60)#waiting for opening chrome 
    driver.get(url)#use get url function for opening of desires site using link provided by user.
def imagedownload(url, folder):#function for getting url and folder name from user and making folder and inserting image in that folder
    try:
        os.mkdir(os.path.join(os.getcwd(), folder))#it will make folder in the current directory where this code file is present
        print("Works Fine")#for exception handling
    except:
        pass
    os.chdir(os.path.join(os.getcwd(), folder))#change the name of directory with the created folder
    r = requests.get(url)#put request for parsing html element approaching these elements through html request
    soup = BeautifulSoup(r.text, 'html.parser')#parsing html by Beatifulsoup function 
    images = soup.find_all('img')#find all tags of img from webpage
    for image in images:# looping through all images to store in folder 
        name = image['alt']#As image tag contains alt and src which are required for getting name of image and src for link helps in downloading
        link = image['src']#getting link using src property present in image tag for downoading ogf image
        with open(name.replace(' ', '-').replace('/', '').replace('\n','-').replace(',','-').replace('*','-') + '.jpg', 'wb') as f:#Here replace function is used to truncate different special characters while saving them in folder due to restriction of some character in saving file.
            im = requests.get(link)#request for getting link through src 
            f.write(im.content)#downloading image on specify path by accessing content 
            print('Image_Name: ', name)#printing name of image for check 
#Calling function for openurl
openurl('https://www.airbnb.co.uk/s/Bratislava--Slovakia/homes?tab_id=home_tab&refinement_paths%5B%5D=%2Fhomes&place_id=ChIJl2HKCjaJbEcRaEOI_YKbH2M&query=Bratislava%2C%20Slovakia&checkin=2020-11-01&checkout=2020-11-22&source=search_blocks_selector_p1_flow&search_type=search_query')
#Calling function for downloading image of scrapped link.
imagedownload('https://www.airbnb.co.uk/s/Bratislava--Slovakia/homes?tab_id=home_tab&refinement_paths%5B%5D=%2Fhomes&place_id=ChIJl2HKCjaJbEcRaEOI_YKbH2M&query=Bratislava%2C%20Slovakia&checkin=2020-11-01&checkout=2020-11-22&source=search_blocks_selector_p1_flow&search_type=search_query', 'images')
