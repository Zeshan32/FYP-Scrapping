from bs4 import BeautifulSoup 
from requests_html import  HTMLSession
i=0
print("works fine",i)
for x in range(1,10):
	url ='https://www.siasat.pk/forums/search/902384/?page='
	print("yes")
	s=HTMLSession()
	r=s.get(url+str(x))
	#r.html.render(sleep=1)
	posts=r.html.xpath('//*[@id="top"]/div[4]/div/div[4]/div/div',first=True)
	for items in posts.absolute_links:
		print("working")
		r=s.get(items)
		if(r.html.find('div.bbWrapper',first=True)):
			post=r.html.find('div.bbWrapper',first=True).text
			print(post+"One done")
			i=i+1	   
print("works fine",i)
