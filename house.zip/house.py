from bs4 import BeautifulSoup 
from requests_html import  HTMLSession
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
import csv
i=0
fname="links.csv"                    #storing name of file to be opened 
f=open(fname,"w",encoding="utf-8")  #open file in append mode
#f.write("Links"+"\n") 
driver=webdriver.Chrome('F:\\chromedriver_win32\\chromedriver.exe')
wait = WebDriverWait(driver,60)
driver.get('https://www.zameen.com/Rentals/Islamabad-3-1.html')
inputelems=driver.find_elements_by_xpath('.//*[@id="body-wrapper"]/main/div[3]/div[2]/div[3]/div[2]/div[1]/h2')
print(inputelems)
for inputelem in inputelems:
	print(inputelem)
"""for inputelem in inputelems:
	inputelem.send_keys('wordpress')
	inputelem.send_keys(Keys.ENTER)                              #giving heading to all the material in first cell which is A1                                #it is looping for the pagination when we have multiple pages and we wnt to scrap data fromm all pages we count	url =driver.current_url        #no of pages and then we loop through all pages 
s=HTMLSession()                  #it is for the http request and return response from http request 
r=s.get(driver.current_url)              #the main purpose for get  function is to take url in its argument then return its function
r.html.render(sleep=0.9) 
for indx in range(0,10):                               #the main function for the render function is to provide services like sleep mode giving time to browser to load completely etc
	links=r.html.xpath('.//*[@id="rso"]/div['+str(indx)+']/div',first=True)
	count=0 
	if links:	                            #//*[@id="rso"]/div[3]/div //*[@id="rso"]/div[4]/div
		for items in links.absolute_links:#first we have to links from the website and then we shall explore them.                   #get function will takes all links one by one 
			if count <1 and items is not None and len(items)<=100:
				f.write(items+"\n") 
				count=count+1
			i=i+1                                                         #https://www.guru99.com/php-tutorials.html
			print(items+"\n")
					                            					       			
		print("works fine",i)"""
