from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from csv import reader
import time
import csv
import re  
import sys 
import os
count=0 
options = webdriver.ChromeOptions()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument("--headless")
driver = webdriver.Chrome('F:\\chromedriver_win32\\chromedriver.exe')
wait = WebDriverWait(driver,60)
csv_file = open('D:\Scrapping\output_scrapping_1.csv', 'a', encoding= "UTF-8", newline="")
writer = csv.writer(csv_file)
posts_link = []
with open ('links.csv', 'r') as f:
    csv_reader = reader (f)
    posts_link = list (csv_reader)

links = []
for link in posts_link:
    links.append(link[0])
for link in links:
	driver.get(link)
	SCROLL_PAUSE_TIME =15
	Cycle = 10
	html = driver.find_element_by_tag_name('html')
	html.send_keys(Keys.PAGE_DOWN)
	html.send_keys(Keys.PAGE_DOWN)
	time.sleep(SCROLL_PAUSE_TIME * 3)
	for i in range(Cycle):
	    html.send_keys(Keys.END)
	    time.sleep(SCROLL_PAUSE_TIME)
	comment_elems = driver.find_elements_by_xpath('//*[@id="content-text"]')
	all_comments = [elem.text for elem in comment_elems]#storing list in "all_comments".
	for Comment in all_comments:
	        status=re.search(r'[\u0600-\u06ff]',Comment)
	        if(status):
	            count=count+1
	            all_comments.remove(Comment)  
	        elif not status:
	            print("\n "+Comment)
	print(count)
	for comment in all_comments:
	    status=re.search(r'[\u0600-\u06ff]',comment)
	    if(status):
	        all_comments.remove(comment)         
	    elif not status:
	        csv_file.write(comment+"\n")            
csv_file.close()



