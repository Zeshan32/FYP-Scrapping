import re  
import sys 
import os 
import enchant
no_of_words=0
string="Pakistan key Haalat thik hone ka"
mylist=string.split(' ')
d = enchant.Dict("en_US")
for word in mylist:
	if not word=='':
		flag=d.check(word)
		print(flag)
	if flag==True:
		no_of_words=no_of_words+1
percent=(no_of_words/len(mylist))*100
if (percent==80 or percent >80):
	print("this is in English!!!!")
elif percent<80:
	print("this is not in English!!!!")


